# In Essentials version 20 or above:
#
#
# Add this to the items.txt file
#
#
#-------------------------------
[LINKSTONE]
Name = Link Stone
NamePlural = Link Stones
Pocket = 1
Price = 3000
FieldUse = OnPokemon
Flags = EvolutionStone,Fling_30
Description = A peculiar stone that makes certain species of Pokémon evolve. It has a link cable pattern.
#-------------------------------
