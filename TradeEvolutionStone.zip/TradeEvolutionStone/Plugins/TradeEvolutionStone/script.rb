class Pokemon
  alias :_old_fl_check_evolution_on_use_item :check_evolution_on_use_item
  def check_evolution_on_use_item(item_used)
    # self is a placeholder here
    return check_evolution_on_trade(self) if item_used==:LINKSTONE
    return _old_fl_check_evolution_on_use_item(item_used)
  end
end